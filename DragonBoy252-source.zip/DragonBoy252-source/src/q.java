/*
 * Decompiled with CFR 0.152.
 */
public final class q {
    public int a;
    public int b;
    public int c;
    public int d;
    public int e;
}

