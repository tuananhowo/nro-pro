/*
 * Decompiled with CFR 0.152.
 */
public final class bs {
    public boolean a;
    public int b = -1;
    public boolean c = false;
}

