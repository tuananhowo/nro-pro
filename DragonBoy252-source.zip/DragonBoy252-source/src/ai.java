/*
 * Decompiled with CFR 0.152.
 */
public final class ai {
    public int a;
    public int b;
    public int c;
}

